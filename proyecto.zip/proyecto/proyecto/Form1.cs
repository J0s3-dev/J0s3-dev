﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace proyecto
{
    public partial class Form1 : Form
    {
        fraccion ob1 = new fraccion();
        fraccion ob2 = new fraccion();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnreturn_Click(object sender, EventArgs e)
        {
            this.Close();
            Program.form3.Show();
        }

        private void btnpow_Click(object sender, EventArgs e)
        {
            ob1.Potencia(textBox1,textBox2,textBox3);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ob2.Segundo(textBox4,textBox5,textBox6,textBox7,textBox8,textBox9,textBox10);
        }
    }
}
