﻿
namespace proyecto
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnexit = new System.Windows.Forms.Button();
            this.btnsiguiente = new System.Windows.Forms.Button();
            this.btnlimpiar = new System.Windows.Forms.Button();
            this.btnigual = new System.Windows.Forms.Button();
            this.btnpunto = new System.Windows.Forms.Button();
            this.btncero = new System.Windows.Forms.Button();
            this.btntres = new System.Windows.Forms.Button();
            this.btndos = new System.Windows.Forms.Button();
            this.btnuno = new System.Windows.Forms.Button();
            this.btnsiete = new System.Windows.Forms.Button();
            this.btnseis = new System.Windows.Forms.Button();
            this.btncinco = new System.Windows.Forms.Button();
            this.btncuatro = new System.Windows.Forms.Button();
            this.btnporcentaje = new System.Windows.Forms.Button();
            this.btnnueve = new System.Windows.Forms.Button();
            this.btnocho = new System.Windows.Forms.Button();
            this.btnraiz = new System.Windows.Forms.Button();
            this.btndivi = new System.Windows.Forms.Button();
            this.btnmulti = new System.Windows.Forms.Button();
            this.btnresta = new System.Windows.Forms.Button();
            this.btnsuma = new System.Windows.Forms.Button();
            this.pantalla = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panel1.Controls.Add(this.btnexit);
            this.panel1.Controls.Add(this.btnsiguiente);
            this.panel1.Controls.Add(this.btnlimpiar);
            this.panel1.Controls.Add(this.btnigual);
            this.panel1.Controls.Add(this.btnpunto);
            this.panel1.Controls.Add(this.btncero);
            this.panel1.Controls.Add(this.btntres);
            this.panel1.Controls.Add(this.btndos);
            this.panel1.Controls.Add(this.btnuno);
            this.panel1.Controls.Add(this.btnsiete);
            this.panel1.Controls.Add(this.btnseis);
            this.panel1.Controls.Add(this.btncinco);
            this.panel1.Controls.Add(this.btncuatro);
            this.panel1.Controls.Add(this.btnporcentaje);
            this.panel1.Controls.Add(this.btnnueve);
            this.panel1.Controls.Add(this.btnocho);
            this.panel1.Controls.Add(this.btnraiz);
            this.panel1.Controls.Add(this.btndivi);
            this.panel1.Controls.Add(this.btnmulti);
            this.panel1.Controls.Add(this.btnresta);
            this.panel1.Controls.Add(this.btnsuma);
            this.panel1.Controls.Add(this.pantalla);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(402, 513);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnexit
            // 
            this.btnexit.Font = new System.Drawing.Font("Segoe UI Symbol", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnexit.Location = new System.Drawing.Point(24, 104);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(159, 57);
            this.btnexit.TabIndex = 22;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btnsiguiente
            // 
            this.btnsiguiente.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnsiguiente.BackgroundImage")));
            this.btnsiguiente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsiguiente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsiguiente.Location = new System.Drawing.Point(217, 104);
            this.btnsiguiente.Name = "btnsiguiente";
            this.btnsiguiente.Size = new System.Drawing.Size(150, 57);
            this.btnsiguiente.TabIndex = 21;
            this.btnsiguiente.UseVisualStyleBackColor = true;
            this.btnsiguiente.Click += new System.EventHandler(this.btnsiguiente_Click);
            // 
            // btnlimpiar
            // 
            this.btnlimpiar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnlimpiar.Location = new System.Drawing.Point(124, 445);
            this.btnlimpiar.Name = "btnlimpiar";
            this.btnlimpiar.Size = new System.Drawing.Size(59, 48);
            this.btnlimpiar.TabIndex = 20;
            this.btnlimpiar.Text = "CE";
            this.btnlimpiar.UseVisualStyleBackColor = true;
            this.btnlimpiar.Click += new System.EventHandler(this.btnlimpiar_Click);
            // 
            // btnigual
            // 
            this.btnigual.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnigual.BackgroundImage")));
            this.btnigual.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnigual.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnigual.Location = new System.Drawing.Point(308, 380);
            this.btnigual.Name = "btnigual";
            this.btnigual.Size = new System.Drawing.Size(59, 113);
            this.btnigual.TabIndex = 19;
            this.btnigual.UseVisualStyleBackColor = true;
            this.btnigual.Click += new System.EventHandler(this.btnigual_Click);
            // 
            // btnpunto
            // 
            this.btnpunto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnpunto.Location = new System.Drawing.Point(217, 445);
            this.btnpunto.Name = "btnpunto";
            this.btnpunto.Size = new System.Drawing.Size(59, 48);
            this.btnpunto.TabIndex = 18;
            this.btnpunto.Text = ".";
            this.btnpunto.UseVisualStyleBackColor = true;
            this.btnpunto.Click += new System.EventHandler(this.btnpunto_Click);
            // 
            // btncero
            // 
            this.btncero.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btncero.BackgroundImage")));
            this.btncero.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncero.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncero.Location = new System.Drawing.Point(24, 445);
            this.btncero.Name = "btncero";
            this.btncero.Size = new System.Drawing.Size(59, 48);
            this.btncero.TabIndex = 17;
            this.btncero.UseVisualStyleBackColor = true;
            this.btncero.Click += new System.EventHandler(this.btncero_Click);
            // 
            // btntres
            // 
            this.btntres.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btntres.BackgroundImage")));
            this.btntres.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btntres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btntres.Location = new System.Drawing.Point(217, 380);
            this.btntres.Name = "btntres";
            this.btntres.Size = new System.Drawing.Size(59, 48);
            this.btntres.TabIndex = 16;
            this.btntres.UseVisualStyleBackColor = true;
            this.btntres.Click += new System.EventHandler(this.btntres_Click);
            // 
            // btndos
            // 
            this.btndos.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btndos.BackgroundImage")));
            this.btndos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btndos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndos.Location = new System.Drawing.Point(124, 380);
            this.btndos.Name = "btndos";
            this.btndos.Size = new System.Drawing.Size(59, 48);
            this.btndos.TabIndex = 15;
            this.btndos.UseVisualStyleBackColor = true;
            this.btndos.Click += new System.EventHandler(this.btndos_Click);
            // 
            // btnuno
            // 
            this.btnuno.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnuno.BackgroundImage")));
            this.btnuno.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnuno.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnuno.Location = new System.Drawing.Point(24, 380);
            this.btnuno.Name = "btnuno";
            this.btnuno.Size = new System.Drawing.Size(59, 48);
            this.btnuno.TabIndex = 14;
            this.btnuno.UseVisualStyleBackColor = true;
            this.btnuno.Click += new System.EventHandler(this.btnuno_Click);
            // 
            // btnsiete
            // 
            this.btnsiete.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnsiete.BackgroundImage")));
            this.btnsiete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsiete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsiete.Location = new System.Drawing.Point(24, 241);
            this.btnsiete.Name = "btnsiete";
            this.btnsiete.Size = new System.Drawing.Size(59, 48);
            this.btnsiete.TabIndex = 13;
            this.btnsiete.UseVisualStyleBackColor = true;
            this.btnsiete.Click += new System.EventHandler(this.btnsiete_Click);
            // 
            // btnseis
            // 
            this.btnseis.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnseis.BackgroundImage")));
            this.btnseis.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnseis.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnseis.Location = new System.Drawing.Point(217, 312);
            this.btnseis.Name = "btnseis";
            this.btnseis.Size = new System.Drawing.Size(59, 48);
            this.btnseis.TabIndex = 12;
            this.btnseis.UseVisualStyleBackColor = true;
            this.btnseis.Click += new System.EventHandler(this.btnseis_Click);
            // 
            // btncinco
            // 
            this.btncinco.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btncinco.BackgroundImage")));
            this.btncinco.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncinco.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncinco.Location = new System.Drawing.Point(124, 312);
            this.btncinco.Name = "btncinco";
            this.btncinco.Size = new System.Drawing.Size(59, 48);
            this.btncinco.TabIndex = 11;
            this.btncinco.UseVisualStyleBackColor = true;
            this.btncinco.Click += new System.EventHandler(this.btncinco_Click);
            // 
            // btncuatro
            // 
            this.btncuatro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btncuatro.BackgroundImage")));
            this.btncuatro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btncuatro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncuatro.Location = new System.Drawing.Point(24, 312);
            this.btncuatro.Name = "btncuatro";
            this.btncuatro.Size = new System.Drawing.Size(59, 48);
            this.btncuatro.TabIndex = 10;
            this.btncuatro.UseVisualStyleBackColor = true;
            this.btncuatro.Click += new System.EventHandler(this.btncuatro_Click);
            // 
            // btnporcentaje
            // 
            this.btnporcentaje.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnporcentaje.BackgroundImage")));
            this.btnporcentaje.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnporcentaje.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnporcentaje.Location = new System.Drawing.Point(308, 241);
            this.btnporcentaje.Name = "btnporcentaje";
            this.btnporcentaje.Size = new System.Drawing.Size(59, 48);
            this.btnporcentaje.TabIndex = 9;
            this.btnporcentaje.UseVisualStyleBackColor = true;
            this.btnporcentaje.Click += new System.EventHandler(this.btnporcentaje_Click);
            // 
            // btnnueve
            // 
            this.btnnueve.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnnueve.BackgroundImage")));
            this.btnnueve.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnnueve.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnnueve.Location = new System.Drawing.Point(217, 241);
            this.btnnueve.Name = "btnnueve";
            this.btnnueve.Size = new System.Drawing.Size(59, 48);
            this.btnnueve.TabIndex = 8;
            this.btnnueve.UseVisualStyleBackColor = true;
            this.btnnueve.Click += new System.EventHandler(this.btnnueve_Click);
            // 
            // btnocho
            // 
            this.btnocho.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnocho.BackgroundImage")));
            this.btnocho.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnocho.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnocho.Location = new System.Drawing.Point(124, 241);
            this.btnocho.Name = "btnocho";
            this.btnocho.Size = new System.Drawing.Size(59, 48);
            this.btnocho.TabIndex = 7;
            this.btnocho.UseVisualStyleBackColor = true;
            this.btnocho.Click += new System.EventHandler(this.btnocho_Click);
            // 
            // btnraiz
            // 
            this.btnraiz.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnraiz.BackgroundImage")));
            this.btnraiz.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnraiz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnraiz.Location = new System.Drawing.Point(308, 312);
            this.btnraiz.Name = "btnraiz";
            this.btnraiz.Size = new System.Drawing.Size(59, 48);
            this.btnraiz.TabIndex = 6;
            this.btnraiz.UseVisualStyleBackColor = true;
            this.btnraiz.Click += new System.EventHandler(this.btnraiz_Click);
            // 
            // btndivi
            // 
            this.btndivi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btndivi.BackgroundImage")));
            this.btndivi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btndivi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndivi.Location = new System.Drawing.Point(308, 167);
            this.btndivi.Name = "btndivi";
            this.btndivi.Size = new System.Drawing.Size(59, 48);
            this.btndivi.TabIndex = 5;
            this.btndivi.UseVisualStyleBackColor = true;
            this.btndivi.Click += new System.EventHandler(this.btndivi_Click);
            // 
            // btnmulti
            // 
            this.btnmulti.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnmulti.BackgroundImage")));
            this.btnmulti.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnmulti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmulti.Location = new System.Drawing.Point(217, 167);
            this.btnmulti.Name = "btnmulti";
            this.btnmulti.Size = new System.Drawing.Size(59, 48);
            this.btnmulti.TabIndex = 4;
            this.btnmulti.UseVisualStyleBackColor = true;
            this.btnmulti.Click += new System.EventHandler(this.btnmulti_Click);
            // 
            // btnresta
            // 
            this.btnresta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnresta.BackgroundImage")));
            this.btnresta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnresta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnresta.Location = new System.Drawing.Point(124, 167);
            this.btnresta.Name = "btnresta";
            this.btnresta.Size = new System.Drawing.Size(59, 48);
            this.btnresta.TabIndex = 3;
            this.btnresta.UseVisualStyleBackColor = true;
            this.btnresta.Click += new System.EventHandler(this.btnresta_Click);
            // 
            // btnsuma
            // 
            this.btnsuma.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnsuma.BackgroundImage")));
            this.btnsuma.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsuma.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsuma.Location = new System.Drawing.Point(24, 167);
            this.btnsuma.Name = "btnsuma";
            this.btnsuma.Size = new System.Drawing.Size(59, 48);
            this.btnsuma.TabIndex = 2;
            this.btnsuma.UseVisualStyleBackColor = true;
            this.btnsuma.Click += new System.EventHandler(this.btnsuma_Click);
            // 
            // pantalla
            // 
            this.pantalla.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.pantalla.Location = new System.Drawing.Point(24, 37);
            this.pantalla.Multiline = true;
            this.pantalla.Name = "pantalla";
            this.pantalla.ReadOnly = true;
            this.pantalla.Size = new System.Drawing.Size(343, 52);
            this.pantalla.TabIndex = 1;
            this.pantalla.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Small", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(67, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Calculadora Básica";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(426, 537);
            this.Controls.Add(this.panel1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnlimpiar;
        private System.Windows.Forms.Button btnigual;
        private System.Windows.Forms.Button btnpunto;
        private System.Windows.Forms.Button btncero;
        private System.Windows.Forms.Button btntres;
        private System.Windows.Forms.Button btndos;
        private System.Windows.Forms.Button btnuno;
        private System.Windows.Forms.Button btnsiete;
        private System.Windows.Forms.Button btnseis;
        private System.Windows.Forms.Button btncinco;
        private System.Windows.Forms.Button btncuatro;
        private System.Windows.Forms.Button btnporcentaje;
        private System.Windows.Forms.Button btnnueve;
        private System.Windows.Forms.Button btnocho;
        private System.Windows.Forms.Button btnraiz;
        private System.Windows.Forms.Button btndivi;
        private System.Windows.Forms.Button btnmulti;
        private System.Windows.Forms.Button btnresta;
        private System.Windows.Forms.Button btnsuma;
        private System.Windows.Forms.TextBox pantalla;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btnsiguiente;
    }
}