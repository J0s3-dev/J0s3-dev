﻿using System;
using System.Collections.Generic;
using System.Text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace proyecto
{
    class operador
    {
        public void Suma(TextBox textBox1, TextBox textBox2,TextBox textBox3,TextBox textBox4,TextBox textBox5,TextBox textBox6)
        {
            double numer1, numer2, denom1, denom2,detalle, numsum,res,resdenm;

            try
            {
                numer1 = Convert.ToDouble(textBox1.Text);
                numer2 = Convert.ToDouble(textBox3.Text);
                denom1 = Convert.ToDouble(textBox2.Text);
                denom2 = Convert.ToDouble(textBox4.Text);

                numsum = (numer1 * denom2);
                detalle = (denom1 * numer2);


                resdenm = denom1 * denom2;

                res = (numsum + detalle);
               

                textBox5.Text = res.ToString();
                textBox6.Text = resdenm.ToString();


            }
            catch (Exception l)
            {

                MessageBox.Show("Error en la entrada deben de ser solo números " + l.Message);
            }
        }

        public void Resta(TextBox textBox1,TextBox textBox2,TextBox textBox3,TextBox textBox4,TextBox textBox5,TextBox textBox6)
        {
            double n1, n2, d1, d2, resnumerador, resdenominador, resu1, resu2;
            try
            {
                n1 = Convert.ToDouble(textBox1.Text);
                d1 = Convert.ToDouble(textBox2.Text);
                n2 = Convert.ToDouble(textBox3.Text);
                d2 = Convert.ToDouble(textBox4.Text);

                resnumerador = (n1 * d2);
                resdenominador = (d1 * n2);
                resu2 = (d1 * d2);
                resu1 = (resnumerador - resdenominador);

                textBox5.Text = resu1.ToString();
                textBox6.Text = resu2.ToString();

            }
            catch (Exception r)
            {

                MessageBox.Show("Error en la entrada solo deben de ser números " + r.Message);
            }


        }

        public void Multiplicacion(TextBox textBox1,TextBox textBox2, TextBox textBox3,TextBox textBox4, TextBox textBox5,TextBox textBox6)
        {
            double num1, num2, den1, den2, nume, denom;

            try
            {
                num1 = Convert.ToDouble(textBox1.Text);
                den1 = Convert.ToDouble(textBox2.Text);
                num2 = Convert.ToDouble(textBox3.Text);
                den2 = Convert.ToDouble(textBox4.Text);

                nume = (num1 * num2);
                denom = (den1 * den2);

                textBox5.Text = nume.ToString();
                textBox6.Text = denom.ToString();


            }
            catch (Exception j)
            {

                MessageBox.Show("Error en la entrada solo deben de ser números " + j.Message);
            }

        }

        public void Divicion(TextBox textBox1,TextBox textBox2,TextBox textBox3,TextBox textBox4,TextBox textBox5,TextBox textBox6)
        {
            double n1, n2, d1, d2, num, den;
            try
            {
                n1 = Convert.ToDouble(textBox1.Text);
                n2 = Convert.ToDouble(textBox2.Text);
                d1 = Convert.ToDouble(textBox3.Text);
                d2 = Convert.ToDouble(textBox4.Text);

                num = (n1 * d2);
                den = (d1 * n2);

                textBox5.Text = num.ToString();
                textBox6.Text = den.ToString();

            }
            catch (Exception f)
            {

                MessageBox.Show("Entrada o datos incorrectos y/o vacios " + f.Message);
            }
        }

    }
}
