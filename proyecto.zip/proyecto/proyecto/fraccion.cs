﻿using System;
using System.Collections.Generic;
using System.Text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace proyecto
{
    class fraccion
    {
        public void Mayormenor(TextBox textBox7,TextBox textBox8,TextBox TextBox9,TextBox textBox10,TextBox textBox11)
        {
            double num1, den1, num2, den2, re1, de1;
            try
            {
                num1 = Convert.ToDouble(textBox7.Text);
                den1 = Convert.ToDouble(textBox8.Text);
                num2 = Convert.ToDouble(TextBox9.Text);
                den2 = Convert.ToDouble(textBox10.Text);

                re1 = (num1 * den2);
                de1 = (den1 * num2);

                if (re1 < de1)
                {
                    textBox11.Text = "<";
                }
                if (re1 == de1)
                {
                    textBox11.Text = "=";
                }
                if (re1 > de1)
                {
                    textBox11.Text = ">";
                }
               
            }
            catch (Exception h)
            {

                MessageBox.Show("Error de entrada y/o no puso núemros o esta vacio " + h.Message);
            }

        }
        public void Fraccmymn(TextBox textBox12,TextBox textBox13,TextBox textBox14)
        {
            double f1, f2;

            try
            {
                f1 = Convert.ToDouble(textBox12.Text);
                f2 = Convert.ToDouble(textBox13.Text);

                if (f1 < f2)
                {
                    textBox14.Text = "<";
                }
                if (f1 == f2)
                {
                    textBox14.Text = "=";
                }
                if (f1 > f2)
                {
                    textBox14.Text = ">";
                }
            }
            catch (Exception s)
            {

                MessageBox.Show("Error de entrada y/o no puso números o esta vacio  \n"
                    +"    "+ s.Message); ;
            }

           
        }

        public void Potencia(TextBox textBox1,TextBox textBox2,TextBox textBox3)
        {
            double x, y,resultado;

            try
            {
                x = Convert.ToDouble(textBox1.Text);
                y = Convert.ToDouble(textBox2.Text);

                resultado = Math.Pow(x, y);

                textBox3.Text = resultado.ToString();

            }
            catch (Exception esy)
            {

                MessageBox.Show("Entrada vacia, falta colocar un número o esta vacia\n"+
                    "   " +esy.Message);
            }

           
        }

        public void Segundo(TextBox textBox4,TextBox textBox5,TextBox textBox6, TextBox textBox7,TextBox textBox8, TextBox textBox9, TextBox textBox10)
        {
            double a, b, c, b1, a1, x, por,res1, res2,res3, res4,res5,se;

            try
            {
                b = Convert.ToDouble(textBox4.Text);
                b1 = Convert.ToDouble(textBox5.Text);
                x = Convert.ToDouble(2);
                a = Convert.ToDouble(textBox6.Text);
                a1 = Convert.ToDouble(textBox8.Text);
                c = Convert.ToDouble(textBox7.Text);

                por = Math.Pow(b1, x);
                res1 = (4 * a * c);
                res2 = 2 * a1;
                se = por - res1;
                res3 = Math.Sqrt(se);

                res4 = (-b + res3) / res2;
                res5 = (-b - res3) / res2;
                MessageBox.Show("El resultado es  " + res4 + " sobre " + res5);

                textBox9.Text = res4.ToString();
                textBox10.Text = res5.ToString();

            }
            catch (Exception l)
            {

                MessageBox.Show("ERROR entrada, falta colocarun número o esta vacia la celda" + l.Message);
            }
            /*Realizado por José Refugio Sánchez Marín , ES172003437, Universidad Abierta y Distancia México*/


        }
    }
}
