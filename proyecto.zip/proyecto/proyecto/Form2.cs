﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace proyecto
{
    public partial class Form2 : Form
    {
        operador suma = new operador();
        operador resta = new operador();
        operador multi = new operador();
        operador div = new operador();
        fraccion q1 = new fraccion();
        fraccion q2 = new fraccion();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnsuma_Click(object sender, EventArgs e)
        {
            suma.Suma(textBox1, textBox2, textBox3, textBox4, textBox5, textBox6);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
        }

        private void btnresta_Click(object sender, EventArgs e)
        {
            resta.Resta(textBox1,textBox2,textBox3,textBox4,textBox5,textBox6);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Program.form3.Show();
            
        }

        private void btnmulti_Click(object sender, EventArgs e)
        {
            multi.Multiplicacion(textBox1,textBox2,textBox3,textBox4,textBox5,textBox6);
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            div.Divicion(textBox1,textBox2,textBox3,textBox4,textBox5,textBox6);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            q1.Mayormenor(textBox7,textBox8,textBox9,textBox10,textBox11);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            q2.Fraccmymn(textBox12, textBox13, textBox14);
        }

        private void btnnext_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 vent = new Form1();
            vent.Show();
        }
    }
}
